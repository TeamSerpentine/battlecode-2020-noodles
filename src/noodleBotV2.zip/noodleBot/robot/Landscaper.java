package noodleBot.robot;

import battlecode.common.*;


public class Landscaper extends AbstractRobotPlayer {

    public boolean hasBeenOnDam = false;
    public int hqHeight;
    public MapLocation droneLoc;
    public MapLocation bestLoc;

    public Landscaper(RobotController rc) throws GameActionException {
        super(rc);
        //Walk randomly until found the own HQ
        while (hqLocation == null) {
            if (findHQ()) {
                determineDam();
            } else {
                tryMove(randomDirection());
            }
            hqHeight = rc.senseElevation(hqLocation);
        }
        team = rc.getTeam();
    }

    @Override
    protected void run() throws GameActionException {
        update();

        if (rc.isReady()) {
            if (tryDefenseDig()) {
                System.out.println("Defended HQ");
            } else if (tryOffenseDeposit()) {
                System.out.println("Deposited Offensive");
            } else if (tryEqualizeHQ()) {
                System.out.println("Trying to Equalize");
            } else if (damSet.isEmpty()) {
                damSetDetermined = determineDam();
            } else if (tryToMove()) {
                System.out.println("Trying to move");
            } else if ((bestDamLocation().equals(currentLocation) || bestLoc.isAdjacentTo(currentLocation))) {
                if (damBuildingPhase) tryBuildOnDam();
            } else if (locLeftOfHQ(bestLoc)) {
                walkLeftOfHQ();
                System.out.println("walking left of HQ");
            } else {
                walkRightOfHQ();
                System.out.println("walking right of HQ");
            }
        }
    }

    public void update() throws GameActionException {
        currentLocation = rc.getLocation();
        if (!damBuildingPhase && rc.getRoundNum() > START_DAM_BUILDING_ROUND) {
            damBuildingPhase = true;
        }
        if (!hasBeenOnDam) {
            hasBeenOnDam = locatedOnDam(currentLocation);
        }
        if(!damSetDetermined){
            damSetDetermined = determineDam();
        }
        if (droneLoc == null) {
            for (RobotInfo r : rc.senseNearbyRobots(-1, team)) {
                if (r.getType() == RobotType.DELIVERY_DRONE) {
                    droneLoc = r.getLocation();
                    break;
                }
            }
        }
    }

    /**
     * tries to undig the HQ
     *
     * @return true - if successful
     * @throws GameActionException
     */
    public boolean tryDefenseDig() throws GameActionException {
        if (currentLocation.isAdjacentTo(hqLocation)) {
            Direction HQDir = currentLocation.directionTo(hqLocation);
            if (rc.canDigDirt(HQDir)) {
                rc.digDirt(HQDir);
                return true;
            } else {
                for (RobotInfo robot : rc.senseNearbyRobots(3, team)) {
                    if (robot.getType().isBuilding()) {
                        Direction dir = currentLocation.directionTo(robot.getLocation());
                        if (rc.canDigDirt(dir)) {
                            rc.digDirt(dir);
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * tries to deposit dirt on an enemy building
     *
     * @return true - if successful
     * @throws GameActionException
     */
    public boolean tryOffenseDeposit() throws GameActionException {
        for (RobotInfo robot : findNearbyEnemies()) {
            if (robot.getLocation().isAdjacentTo(currentLocation)) {
                if (robot.getType().isBuilding()) {
                    tryToDepositDirt(currentLocation.directionTo(robot.getLocation()));
                    return true;
                } else {
                    for (Direction dir : directions) {
                        if (rc.canDigDirt(dir)) {
                            rc.digDirt(dir);
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * tries to deposit dirt on an adjacent dam position
     *
     * @return true - if successfull
     * @throws GameActionException
     */
    public boolean tryBuildOnDam() throws GameActionException {
        System.out.println("trying to deposit on dam");
        if (rc.getDirtCarrying() <= 0) {
            if (hasBeenOnDam) {
                //dig away from the hq
                if (tryToDigDirt(hqLocation.directionTo(currentLocation))) return true;
                for (Direction d : directions) {
                    if (getDistance(currentLocation.add(d), hqLocation) == 3) {
                        if (tryToDigDirt(d)) return true;
                    }
                }
                return false;
            } else {
                if (hqLocation.add(Direction.EAST).equals(currentLocation)) {
                    return tryToDigDirt(Direction.NORTH);
                } else {
                    return tryToDigDirt(Direction.CENTER);
                }
            }
        } else {
            System.out.println("Deposited on dam");
            Direction damDir = lowestDamDirection();
            System.out.println("Deposited" + damDir);
            return tryToDepositDirt(damDir);
        }
    }

    /**
     * landscaper tries to deposit dirt in given direction
     *
     * @param dir to deposit
     * @return true if deposited dirt
     * @throws GameActionException
     */
    public boolean tryToDepositDirt(Direction dir) throws GameActionException {
        System.out.println("Trying to deposit dirt in " + dir);
        if (rc.isReady() && rc.canDepositDirt(dir)) {
            rc.depositDirt(dir);
            return true;
        } else {
            return false;
        }
    }

    /**
     * landscaper tries to dig dirt in given direction
     *
     * @param dir to dig
     * @return true if digged dirt
     * @throws GameActionException
     */
    public boolean tryToDigDirt(Direction dir) throws GameActionException {
        if (rc.isReady() && rc.canDigDirt(dir)) {
            rc.digDirt(dir);
            return true;
        } else {
            return false;
        }
    }

    /**
     * tries to move to the lowest Dam direction
     * returns true if successful
     * false if it already is on that location or cant move to that direction
     *
     * @return
     * @throws GameActionException
     */
    public boolean tryMoveToLowestDamDir() throws GameActionException {
        Direction lowestDir = lowestDamDirection();
        if (lowestDir != Direction.CENTER) {
            System.out.println("Moving to lowest direction" + lowestDir);
            return tryMoveExact(lowestDir);
        }
        System.out.println("Already on lowest direction");
        return true;
    }


    /**
     * Moves in the direction of the dam
     * returns true if successfully made it on the dam
     *
     * @return true - if after move located on dam
     * @throws GameActionException
     */
    public boolean tryMoveToDam() throws GameActionException {
        if (!adjacentToDam(currentLocation)) {
            for (Direction dir : Direction.allDirections()) {
                if (locatedOnDam(currentLocation.add(dir))) {
                    if (tryMove(dir)) {
                        return true;
                    }
                }
            }
        } else {
            int closest = 1000;
            MapLocation closestDam = damSet.iterator().next();
            for (MapLocation dam : damSet) {
                int distance = currentLocation.distanceSquaredTo(dam);
                if (distance < closest) {
                    closest = distance;
                    closestDam = dam;
                }
            }
            moveToLocation(closestDam);
        }
        return false;

    }


    /**
     * Returns the direction where the (reachable) dam is lowest
     *
     * @return
     * @throws GameActionException
     */
    public Direction lowestDamDirection() throws GameActionException {
        int lowestHeight;
        Direction lowestDir = Direction.CENTER; //should get overwritten by the first damLoc
        if (hasBeenOnDam) {
            lowestHeight = rc.senseElevation(currentLocation);
        } else {
            lowestHeight = 10000; //everything should be lower then here
        }
        for (Direction dir : Direction.allDirections()) {
            MapLocation loc = currentLocation.add(dir);
            if (rc.canSenseLocation(loc) && locatedOnDam(loc)) {
                int damHeight = rc.senseElevation(loc);
                System.out.println(lowestHeight + ">" + damHeight);
                if (lowestHeight > damHeight) {
                    lowestDir = dir;
                    lowestHeight = damHeight;
                    System.out.println("Lowest direction on the dam:" + lowestDir + " with a height of:" + lowestHeight + "location:" + loc);
                }
            }
        }
        System.out.println("found the lowest direction on the dam:" + lowestDir + " with a height of:" + lowestHeight);
        return lowestDir;
    }

    public boolean tryMoveOnDam(MapLocation damLocation) throws GameActionException {
        Direction lowestDir = currentLocation.directionTo(damLocation);
        //if the direction towards which this landscaper wants to move is on the dam
        if (locatedOnDam(currentLocation.add(lowestDir)) && tryMoveExact(lowestDir)) {
            return true;
        } else {
            for (Direction dir : Direction.allDirections()) {
                if (locatedOnDam(currentLocation.add(dir))) {
                    if (tryMove(dir)) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    public boolean adjacentToDam(MapLocation loc) {
        for (MapLocation dam : damSet) {
            if (loc.isAdjacentTo(dam)) {
                return true;
            }
        }
        return false;
    }

    public boolean tryEqualizeHQ() throws GameActionException {
        if (rc.getDirtCarrying() > 1 && tryEqualizeDeposit()) {
            return true;
        } else if (rc.getDirtCarrying() < RobotType.LANDSCAPER.dirtLimit) {
            return tryEqualizeDig();
        } else if (rc.getDirtCarrying() >= RobotType.LANDSCAPER.dirtLimit) {
            return tryBuildOnDam();
        }
        return true;
    }

    public boolean tryEqualizeDig() throws GameActionException {
        for (Direction dir : Direction.allDirections()) {
            MapLocation loc = currentLocation.add(dir);
            if (loc.isAdjacentTo(hqLocation) && rc.canSenseLocation(loc)) {
                if (rc.senseElevation(loc) - hqHeight > GameConstants.MAX_DIRT_DIFFERENCE) {
                    if (tryToDigDirt(dir)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean tryEqualizeDeposit() throws GameActionException {
        for (Direction dir : Direction.allDirections()) {
            MapLocation loc = currentLocation.add(dir);
            if (loc.isAdjacentTo(hqLocation) && rc.canSenseLocation(loc)) {
                if (hqHeight - rc.senseElevation(loc) > GameConstants.MAX_DIRT_DIFFERENCE) {
                    if (tryToDepositDirt(dir)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Neighbouring DamLocation with lowest elevation
     *
     * @return Neighbouring MapLocation with lowest elevation
     * @throws GameActionException
     */
    public MapLocation lowestNeighbourLocation() throws GameActionException {
        int lowestHeight = 10000;
        MapLocation lowestLoc = null;
        for (Direction d : directions) {
            MapLocation loc = currentLocation.add(d);
            if (rc.canSenseLocation(loc) && locatedOnDam(loc)) {
                int damHeight = rc.senseElevation(loc);
                if (lowestHeight > damHeight) {
                    lowestLoc = loc;
                    lowestHeight = damHeight;
                }
            }
        }
        return lowestLoc;
    }

    /**
     * Decides the best loc to build on the dam
     *
     * @return DamLocation with lowest elevation or neighbour Location
     * @throws GameActionException
     */
    public MapLocation bestDamLocation() throws GameActionException {
        MapLocation damLoc = lowestDamLoc();
        MapLocation neighbourLoc = lowestNeighbourLocation();
        if (rc.senseElevation(damLoc) + 2 < rc.senseElevation(neighbourLoc)) {
            bestLoc = damLoc;
            System.out.println("walking to: " + bestLoc);
            return damLoc;
        }
        bestLoc = neighbourLoc;
        System.out.println("trying to build dike: " + bestLoc);
        return neighbourLoc;
    }

    /**
     * is the loc that has to be reached left of right of the location? This is important for pathfinding on the dam
     *
     * @param m - the location tested on direction relative to the hq
     * @return true - location is left of hq
     * @throws GameActionException
     */
    public boolean locLeftOfHQ(MapLocation m) throws GameActionException {
        Direction dir = currentLocation.directionTo(m);
        Direction hqDir = currentLocation.directionTo(hqLocation);
        for (int i = 0; i < 4; i++) {
            if (hqDir.equals(dir)) {
                return true;
            }
            dir = dir.rotateRight();
        }
        return false;
    }

    /**
     * walk over the dam on the left side of the hq
     *
     * @return true - if moved
     * @throws GameActionException
     */
    public boolean walkLeftOfHQ() throws GameActionException {
        Direction hqDir = currentLocation.directionTo(hqLocation);
        for (int i = 0; i < 4; i++) {
            if (locatedOnDam(currentLocation.add(hqDir)) && tryMoveExact(hqDir)) return true;
            hqDir = hqDir.rotateLeft();
        }
        return false;
    }

    /**
     * walk over the dam on the left side of the hq
     *
     * @return true - if moved
     * @throws GameActionException
     */
    public boolean walkRightOfHQ() throws GameActionException {
        Direction hqDir = currentLocation.directionTo(hqLocation);
        for (int i = 0; i < 4; i++) {
            if (locatedOnDam(currentLocation.add(hqDir)) && tryMoveExact(hqDir)) return true;
            hqDir = hqDir.rotateRight();
        }
        return false;
    }

    /**
     * walk away for more LS if needed
     *
     * @return true - if the LS needs to move
     * @throws GameActionException
     */
    public boolean tryToMove() throws GameActionException {
        if (rc.getRoundNum() % 60 != 0) return false;
        else if (locLeftOfHQ(droneLoc)) return walkRightOfHQ(); //TODO: add another statement to not walk always
        else return walkLeftOfHQ();
        /*
        Direction dir = needToMove();
        if (!dir.equals(Direction.CENTER) && tryMoveExact(dir)) {
            return true;
        } */
    }

    /**
     * decides whether to walk away for more LS and in which direction
     *
     * @return Direction.Center - don't move, else direction to move
     * @throws GameActionException
     */
    public Direction needToMove() throws GameActionException {
        if (locatedOnDam(currentLocation) && droneLoc != null) {
            //Direction dir = moveAroundTheCorner();
            //if (!dir.equals(Direction.CENTER)) return dir;
            /*else */return moveNormal();
        }
        return Direction.CENTER;
    }

    /**
     * check if a corner can be skipped to walk over the dike
     *
     * @return Direction of the corner that can be skipped or Direction.CENTER
     * @throws GameActionException
     */
//    public Direction moveAroundTheCorner() throws GameActionException {
//        if (currentLocation.isAdjacentTo(damSet[(damIndex + 18) % 16]) &&
//                rc.senseRobotAtLocation(damSet[(damIndex + 18) % 16]) == null &&
//                rc.senseRobotAtLocation(damSet[(damIndex + 15) % 16]) != null &&
//                rc.senseRobotAtLocation(damSet[(damIndex + 14) % 16]) != null &&
//                !isDrone(damSet[(damIndex + 18) % 16]))
//            return currentLocation.directionTo(damSet[(damIndex + 18) % 16]);
//        else if (currentLocation.isAdjacentTo(damSet[(damIndex + 14) % 16]) &&
//                rc.senseRobotAtLocation(damSet[(damIndex + 14) % 16]) == null &&
//                rc.senseRobotAtLocation(damSet[(damIndex + 17) % 16]) != null &&
//                rc.senseRobotAtLocation(damSet[(damIndex + 18) % 16]) != null &&
//                !isDrone(damSet[(damIndex + 14) % 16]))
//            return currentLocation.directionTo(damSet[(damIndex + 14) % 16]);
//        return Direction.CENTER;
//    }

    /**
     * check if the LS should move to make place for more
     *
     * @return Direction the LS should move or Direction.CENTER
     * @throws GameActionException
     */
    public Direction moveNormal() throws GameActionException {
        /*
        if (rc.senseRobotAtLocation(damSet[(damIndex + 17) % 16]) == null &&
                rc.senseRobotAtLocation(damSet[(damIndex + 15) % 16]) != null &&
                rc.senseRobotAtLocation(damSet[(damIndex + 14) % 16]) != null &&
                !isDrone(damSet[(damIndex + 17) % 16]))
            return currentLocation.directionTo(damSet[(damIndex + 17) % 16]);
        else if (rc.senseRobotAtLocation(damSet[(damIndex + 15) % 16]) == null &&
                rc.senseRobotAtLocation(damSet[(damIndex + 17) % 16]) != null &&
                rc.senseRobotAtLocation(damSet[(damIndex + 18) % 16]) != null &&
                !isDrone(damSet[(damIndex + 17) % 16]))
            return currentLocation.directionTo(damSet[(damIndex + 15) % 16]); */
        return Direction.CENTER;
    }

    /**
     * check if there is a drone next to the tile that the LS could move to
     *
     * @return true - if there is a drone
     * @throws GameActionException
     */
    public boolean isDrone(MapLocation m) {
        for (RobotInfo r : rc.senseNearbyRobots(m, 3, team)) {
            if (r.getType().equals(RobotType.DELIVERY_DRONE)) return true;
        }
        return false;
    }

    public boolean onReserved() {
        return occupiedPlaces.contains(currentLocation);
    }
}