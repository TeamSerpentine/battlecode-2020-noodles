package noodleBot.robot;

import battlecode.common.*;
import gnu.trove.list.linked.TLinkedList;

import java.util.LinkedList;

public class DesignSchool extends AbstractRobotPlayer {

    static int amountOfLS;

    static MapLocation flightCenter;

    public DesignSchool(RobotController rc) {
        super(rc);
        currentLocation = rc.getLocation();
        for (RobotInfo r : findNearbyFriendlies()) {
            if (r.getType() == RobotType.FULFILLMENT_CENTER)
                flightCenter = r.getLocation();
            else if (r.getType() == RobotType.HQ)
                hqLocation = r.getLocation();
        }
    }

    @Override
    protected void run() throws GameActionException {
        if (needMoreLS()) {
            for (Direction dir : allowedDirs()) {
                if (currentLocation.add(dir).isAdjacentTo(hqLocation) && tryBuild(RobotType.LANDSCAPER, dir)) {
                    System.out.println("Build Landscaper");
                }
            }
        }
    }

    protected boolean needMoreLS() throws GameActionException {
        amountOfLS = 0;
        allowedDirs();
        for (RobotInfo r : rc.senseNearbyRobots(rc.getCurrentSensorRadiusSquared(), team)) {
            if (r.getType().equals(RobotType.LANDSCAPER)) amountOfLS++;
        }
        if (amountOfLS < LANDSCAPERS_BATCH_1) return true;
        else if (rc.getTeamSoup() > 300) {
            for (RobotInfo r : rc.senseNearbyRobots(rc.getCurrentSensorRadiusSquared(), team)) {
                if (r.getType().equals(RobotType.DELIVERY_DRONE)) return true;
            }
        }
        return false;
    }

    protected LinkedList<Direction> allowedDirs() {
        LinkedList<Direction> allowed = new LinkedList<>();
        for (Direction dir : Direction.allDirections()) {
            if (currentLocation.add(dir).isAdjacentTo(hqLocation) && !isReserved(currentLocation.add(dir))) {
                allowed.add(dir);
            }
        }
        return allowed;
    }

    protected boolean isReserved(MapLocation location) {
        return occupiedPlaces.contains(location);
    }
}
