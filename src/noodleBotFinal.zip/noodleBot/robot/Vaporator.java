package noodleBot.robot;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Vaporator extends AbstractRobotPlayer {
    public Vaporator(RobotController rc) {
        super(rc);
    }

    @Override
    protected void run() throws GameActionException {

    }
}
