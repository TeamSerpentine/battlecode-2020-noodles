package noodleBot.robot;

import battlecode.common.*;

import java.util.ArrayList;


public class Miner extends AbstractRobotPlayer {
    public int myMission; //1 = DS, 2 = V, 3 = FC
    public MapLocation senseLocation;
    public ArrayList<MapLocation> reservedLocations = new ArrayList<>();
    public boolean reservedSet;
    public boolean stopHQSoon;
    public boolean stopGoingToHQ;
    public int roundsWithoutRefinery = 0;
    public Direction scoutDir;

    public Miner(RobotController rc) {
        super(rc);
        initLocations();
        initMission();
    }

    @Override
    protected void run() throws GameActionException {
        currentLocation = rc.getLocation();
        decodeBlock(rc.getRoundNum() - 1);
        updateFromVision();
        if (rc.isReady()) {
            if (!damSetDetermined) {
                damSetDetermined = determineDam();
            }
            if (damBuildingPhase || rc.getRoundNum() > START_DAM_BUILDING_ROUND) {
                evacuateHQ();
            }
            if (hasTasks()) {
                doTasks();
            } else if (!tryResourceHunt()) {
                ecoBoost();
                scout();

            }
        }
        droneDefense();
    }

    public boolean hasTasks() {
        return !unitTask.isEmpty();
    }

    public void evacuateHQ() throws GameActionException {
        if (insideDam(currentLocation) || damSet.contains(currentLocation)) {
            System.out.println("Suicide");
            if (rc.isReady() && !tryMoveExact(hqLocation.directionTo(currentLocation))) {
                tryRefine(currentLocation.directionTo(hqLocation));
                rc.disintegrate();
            }
        }
    }


    public void doTasks() throws GameActionException {
        if (!unitTask.isEmpty()) {
            System.out.println("I have a task!");
            for (pointOfInterest task : unitTask) {
                System.out.println(task);
                if (tryBuildPoint(task)) {
                    System.out.println(codeToType(task.buildCode));
                    unitTask.remove(task);
                }
            }
        }
    }

    public boolean tryResourceHunt() throws GameActionException {
        if (rc.getSoupCarrying() >= RobotType.MINER.soupLimit - GameConstants.SOUP_MINING_RATE) {
            goToRefinery();
            System.out.println("Moving to refinery");
            System.out.println("I have: " + rc.getSoupCarrying() + " soup");
            return true;
        } else if (nextToSoup()) {
            mineSoup();
            System.out.println("Mining soup");
            return true;
        } else {
            MapLocation soup = senseClosestSoup();
            if (soup != null) {
                moveToLocation(soup);
                System.out.println("Moving to soup");
                return true;
            }
            return false;
        }
    }

    public void ecoBoost() throws GameActionException {
        if (rc.getRoundNum() < 400 && (damBuildingPhase || rc.getTeamSoup() >= RobotType.VAPORATOR.cost + RESERVE_SOUP)) {
            tryBuildHighest(RobotType.VAPORATOR);
        }
    }

    public void scout() throws GameActionException {
        System.out.println("Scouting the area");
        if (hqLocation.distanceSquaredTo(currentLocation) > 6) {
            RobotInfo[] robots = rc.senseNearbyRobots();
            System.out.println(robots);
            boolean sawOthers = false;
            for (RobotInfo robot : robots) {
                System.out.println(robot.getLocation());
                if (robot.getID() != rc.getID()) {
                    tryMove(robot.location.directionTo(currentLocation));
                    sawOthers = true;
                }
            }
            if (!sawOthers) {
                if (!tryMove(hqLocation.directionTo(currentLocation))) {
                    tryMove(randomDirection());
                }
            }
        } else {
            tryMove(hqLocation.directionTo(currentLocation));
        }
    }

    public void updateFromVision() {
        for (RobotInfo r : findNearbyFriendlies()) {
            if (r.getType() == RobotType.REFINERY) {
                refineries.add(r.getLocation());
            }
        }
    }

    public void droneDefense() throws GameActionException {
        for (RobotInfo robot : findNearbyEnemies()) {
            if (robot.getType() == RobotType.DELIVERY_DRONE) {
                emergencySignal(robot);
                if (rc.getTeamSoup() > 650) {
                    tryBuildHighest(RobotType.NET_GUN);
                }

            }
        }
    }

    public void emergencySignal(RobotInfo robot) throws GameActionException {
        pointOfInterest enemy = new pointOfInterest(ENEMY_DRONE_CODE, robot.getLocation(), robot.getID());
        trySendMessage(enemy);
    }

    public boolean tryBuildHighest(RobotType building) throws GameActionException {
        System.out.println("Try eco boost");
        int maxHeight = 0;
        int currentHeight = rc.senseElevation(currentLocation);
        Direction highestDir = null;
        for (Direction dir : Direction.allDirections()) {
            MapLocation tmpLoc = currentLocation.add(dir);
            if (rc.canSenseLocation(tmpLoc) && !rc.isLocationOccupied(tmpLoc)) {
                int tmpHeight = rc.senseElevation(tmpLoc);
                if (tmpHeight > maxHeight && Math.abs(tmpHeight - currentHeight) <= GameConstants.MAX_DIRT_DIFFERENCE) {
                    highestDir = dir;
                    maxHeight = tmpHeight;
                }
            }

        }
        if (highestDir != null) {
            System.out.println(highestDir);
            System.out.println(maxHeight);
            return tryBuild(building, highestDir);
        }
        return false;
    }

    public boolean tryMove(Direction dir) throws GameActionException {
        for (int i = 0; i < 8; i++) {
            if (rc.canMove(dir) && !rc.senseFlooding(currentLocation.add(dir))
                    && (allowed(currentLocation.add(dir)) || !allowed(currentLocation))) {
                rc.move(dir);
                return true;
            }
            if (turnside)
                dir = dir.rotateRight();
            else
                dir = dir.rotateLeft();
        }
        return false;
    }

    public void goToRefinery() throws GameActionException {
        int minDist = 1000;
        MapLocation minDistLoc = null;
        if (!refineries.isEmpty()) {
            for (MapLocation m : refineries) {
                if (getDistance(m, currentLocation) < minDist) {
                    minDist = getDistance(m, currentLocation);
                    minDistLoc = m;
                }
            }
        }
        System.out.println(minDistLoc + " is " + minDist + " away");
        if (minDist <= 1) {
            tryRefine(currentLocation.directionTo(minDistLoc));
        } else if (minDist >= REFINERY_DISTANCE) {
            System.out.println(roundsWithoutRefinery);
            if (nextToSoup()) {
                buildRefinery();
            } else if (senseClosestSoup() != null) {
                moveToAdjecentLocation(senseClosestSoup());
            } else if (roundsWithoutRefinery > MAX_ROUNDS_WITHOUT_REFINERY) {
                buildRefinery();
            } else {
                roundsWithoutRefinery++;
            }
        } else if (minDist != 1000) {
            moveToLocation(minDistLoc);
        }
    }


    /**
     * Attempts to refine soup in a given direction.
     *
     * @param dir The intended direction of refining
     * @return true if a move was performed
     * @throws GameActionException
     */
    public boolean tryRefine(Direction dir) throws GameActionException {
        if (rc.isReady() && rc.canDepositSoup(dir)) {
            rc.depositSoup(dir, rc.getSoupCarrying());
            return true;
        } else return false;
    }

    public void buildRefinery() throws GameActionException {
        for (Direction dir : Direction.allDirections()) {
            MapLocation loc = currentLocation.add(dir);
            if (rc.canSenseLocation(loc) && rc.isReady() && rc.canBuildRobot(RobotType.REFINERY, dir)
                    && !insideDam(loc) && !damSet.contains(loc)) {
                rc.buildRobot(RobotType.REFINERY, dir);
                pointOfInterest refinery = new pointOfInterest(REFINERY_CODE, currentLocation.add(dir), -1);
                trySendMessage(refinery);
            }
        }
    }

    public boolean tryBuildPoint(pointOfInterest point) throws GameActionException {
        MapLocation loc = point.location;
        RobotType building = codeToType(point.buildCode);
        if (currentLocation.isAdjacentTo(loc) && !currentLocation.equals(loc)) {
            if (tryBuild(building, currentLocation.directionTo(loc))) {
                return true;
            }
        } else if (currentLocation.equals(loc)) {
            tryMove(randomDirection());
        } else {
            // else go to design school location
            moveToLocation(loc);
        }
        return false;

    }


    public boolean nextToSoup() throws GameActionException {
        for (Direction d : directions) {
            senseLocation = currentLocation.add(d);
            if (rc.canSenseLocation(senseLocation) && rc.senseSoup(senseLocation) > 0) {
                return true;
            }
        }
        return false;
    }

    public void mineSoup() throws GameActionException {
        for (Direction d : directions) {
            tryMine(d);
        }
    }

    public void updateReserved() {
        if (stopHQSoon && rc.getTeamSoup() > 250 || rc.getRoundNum() > 310) {
            stopHQSoon = false;
            stopGoingToHQ = true;
            reservedLocations.clear();
            for (int i = -2; i <= 2; i++) {
                for (int j = -2; j <= 2; j++) {
                    reservedLocations.add(currentLocation.translate(i, j));
                }
            }
        }
    }

    public boolean allowed(MapLocation m) {
        for (MapLocation l : reservedLocations) {
            if (m.equals(l))
                return false;
        }
        return true;
    }

    public void initLocations() {
        for (RobotInfo robot : rc.senseNearbyRobots(2, rc.getTeam())) {
            if (robot.type == RobotType.HQ) {
                hqLocation = robot.location;
                refineries.add(hqLocation);
                break;
            }
        }
    }

    public void initMission() {
        try {
            lastBlockchain = rc.getBlock(rc.getRoundNum() - 1);
            for (Transaction t : lastBlockchain) {
                lastMessage = t.getMessage();
                if (lastMessage[0] == VP_CODE && lastMessage[1] == TEAM_CODE) {
                    myMission = 2;
                } else if (lastMessage[0] == DS_CODE && lastMessage[1] == TEAM_CODE) {
                    myMission = 1;
                }
            }
        } catch (Exception GameActionException) {
            System.out.println("wrong blockchain location");
        }
    }

    public void goThroughBlockChain() throws GameActionException {
        lastBlockchain = rc.getBlock(rc.getRoundNum() - 1);
        for (Transaction t : lastBlockchain) {
            lastMessage = t.getMessage();
            if (lastMessage[0] == VP_CODE && lastMessage[1] == TEAM_CODE) {
                stopHQSoon = true;
            }
            if (lastMessage[0] == REFINERY_CODE && lastMessage[1] == TEAM_CODE) {
                try {
                    MapLocation ref = new MapLocation(lastMessage[2], lastMessage[3]);
                    refineryLocations.add(ref);
                    if (!nextToSoup() && destination == null) {
                        destination = ref;
                    }
                } catch (Exception GameActionException) {
                    System.out.println("wrong blockchain location");
                }
            }
        }
    }
}

