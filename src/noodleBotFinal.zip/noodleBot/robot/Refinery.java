package noodleBot.robot;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Refinery extends AbstractRobotPlayer {
    public Refinery(RobotController rc) {
        super(rc);
    }

    @Override
    protected void run() throws GameActionException {

    }
}
